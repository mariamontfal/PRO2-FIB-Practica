var searchData=
[
  ['tab_5fclu_108',['Tab_clu',['../class_cjt__clusters.html#a9cbca9fffbe8f050e0c2050627e4d54f',1,'Cjt_clusters']]],
  ['tabla_109',['Tabla',['../class_cjt__especies.html#afb202e1d944b7d3761a99181c7e43239',1,'Cjt_especies']]]
];
