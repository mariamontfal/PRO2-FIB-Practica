var searchData=
[
  ['dist_5fminima_17',['dist_minima',['../class_cjt__clusters.html#abd909eeef377c0a78a7c21b9522304e0',1,'Cjt_clusters']]],
  ['distancia_18',['distancia',['../class_especie.html#a399c911e6920adc909c2036d6bb2635f',1,'Especie']]],
  ['distancia_5fcjt_19',['distancia_cjt',['../class_cjt__especies.html#ab59e25df0794d18893a1fe0fc1b86da6',1,'Cjt_especies']]],
  ['distancia_5fcl_20',['distancia_cl',['../class_cjt__clusters.html#adfc3056ce8f41adc4288c61d97f8de5b',1,'Cjt_clusters']]]
];
