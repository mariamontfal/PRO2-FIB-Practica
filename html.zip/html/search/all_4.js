var searchData=
[
  ['fusiona_5fcluster_29',['fusiona_cluster',['../class_cjt__clusters.html#ab7cbb94abaef1feb073512090fac052a',1,'Cjt_clusters']]]
];
