var searchData=
[
  ['kmer_40',['kmer',['../class_especie.html#ab6740db160f2d7335a98fa8d9f745cbe',1,'Especie']]]
];
