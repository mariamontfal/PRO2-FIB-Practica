var searchData=
[
  ['tab_5fclu_48',['Tab_clu',['../class_cjt__clusters.html#a9cbca9fffbe8f050e0c2050627e4d54f',1,'Cjt_clusters']]],
  ['tabla_49',['Tabla',['../class_cjt__especies.html#afb202e1d944b7d3761a99181c7e43239',1,'Cjt_especies']]],
  ['tabla_5fdistancias_50',['tabla_distancias',['../class_cjt__especies.html#a653d6b120928015ad38a5dc30ebeec8e',1,'Cjt_especies']]]
];
