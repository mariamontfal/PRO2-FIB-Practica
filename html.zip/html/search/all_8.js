var searchData=
[
  ['lee_5fcjt_5fespecies_41',['lee_cjt_especies',['../class_cjt__especies.html#a7ddd1ba65a5f594da23780f1ccaa5682',1,'Cjt_especies']]],
  ['lee_5fespecie_42',['lee_especie',['../class_especie.html#a56ca4b4f3e11d085e0870e3f911be0bb',1,'Especie']]]
];
