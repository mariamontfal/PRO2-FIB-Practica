var searchData=
[
  ['obtener_5fgen_44',['obtener_gen',['../class_cjt__especies.html#aa3a4ba2dd9cf056739ab0a97c549379d',1,'Cjt_especies']]],
  ['obtener_5fkmer_45',['obtener_kmer',['../class_especie.html#ab273a883d4048f3013b51f6e5abc8e06',1,'Especie']]]
];
