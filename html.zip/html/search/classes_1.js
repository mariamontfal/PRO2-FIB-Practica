var searchData=
[
  ['especie_56',['Especie',['../class_especie.html',1,'']]]
];
